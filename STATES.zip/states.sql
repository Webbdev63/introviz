-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 29, 2024 at 07:19 AM
-- Server version: 10.11.7-MariaDB-cll-lve
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u469547012_introviz`
--

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE `states` (
  `id` int(11) NOT NULL,
  `state` varchar(55) NOT NULL,
  `state_code` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `states`
--

INSERT INTO `states` (`id`, `state`, `state_code`) VALUES
(2, 'Alaska', 'AK'),
(3, 'Alabama', 'AL'),
(4, 'Arkansas', 'AR'),
(5, 'Arizona', 'AZ'),
(6, 'California', 'CA'),
(7, 'Colorado', 'CO'),
(8, 'Connecticut', 'CT'),
(9, 'District of Columbia', 'DC'),
(10, 'Delaware', 'DE'),
(11, 'Florida', 'FL'),
(12, 'Georgia', 'GA'),
(13, 'Hawaii', 'HI'),
(14, 'Iowa', 'IA'),
(15, 'Idaho', 'ID'),
(16, 'Illinois', 'IL'),
(17, 'Indiana', 'IN'),
(18, 'Kansas', 'KS'),
(19, 'Kentucky', 'KY'),
(20, 'Louisiana', 'LA'),
(21, 'Massachusetts', 'MA'),
(22, 'Maryland', 'MD'),
(23, 'Maine', 'ME'),
(24, 'Michigan', 'MI'),
(25, 'Minnesota', 'MN'),
(26, 'Missouri', 'MO'),
(27, 'Mississippi', 'MS'),
(28, 'Montana', 'MT'),
(29, 'North Carolina', 'NC'),
(30, 'North Dakota', 'ND'),
(31, 'Nebraska', 'NE'),
(32, 'New Hampshire', 'NH'),
(33, 'New Jersey', 'NJ'),
(34, 'New Mexico', 'NM'),
(35, 'Nevada', 'NV'),
(36, 'New York', 'NY'),
(37, 'Ohio', 'OH'),
(38, 'Oklahoma', 'OK'),
(39, 'Oregon', 'OR'),
(40, 'Pennsylvania', 'PA'),
(41, 'Rhode Island', 'RI'),
(42, 'South Carolina', 'SC'),
(43, 'South Dakota', 'SD'),
(44, 'Tennessee', 'TN'),
(45, 'Texas', 'TX'),
(46, 'Utah', 'UT'),
(47, 'Virginia', 'VA'),
(48, 'Vermont', 'VT'),
(49, 'Washington', 'WA'),
(50, 'Wisconsin', 'WI'),
(51, 'West Virginia', 'WV'),
(52, 'Wyoming', 'WY');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `states`
--
ALTER TABLE `states`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `states`
--
ALTER TABLE `states`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
